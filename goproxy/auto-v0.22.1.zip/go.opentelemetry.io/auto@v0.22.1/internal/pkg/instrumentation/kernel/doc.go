// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

// Package kernel provides access to the operating system kernel state and
// settings.
package kernel
